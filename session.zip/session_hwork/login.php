<?php
session_start();

if(isset($_POST["LoginButton"]))
{
$_SESSION["UserName"] =$_POST["UsNa"];
$_SESSION["UserPassword"]= $_POST["Password"];

header('location: index.php');

}
?>

<form name="UserLogin" method="post" action="">
<table width="354" border="0" cellpadding="2" cellspacing="5">
  <tr>
    <td width="130" height="25">Kullanıcı Adı</td>
    <td width="12">:</td>
    <td width="189">
      <label for="UsNa"></label>
      <input type="text" name="UsNa" id="UsNa">
    </td>
  </tr>
  <tr>
    <td>Kullanıcı Şifresi</td>
    <td>:</td>
    <td><input type="text" name="Password" id="Password"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>
      <input type="submit" name="LoginButton" id="LoginButton" value="Giriş Yap">
   </td>
  </tr>
</table>
</form>
